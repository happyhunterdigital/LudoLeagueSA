import { useEffect, useState } from 'react';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../config/firebase';
import { Loader2, CheckCircle2, UploadCloud, CreditCard, Landmark, Crown } from 'lucide-react';

interface KingsTableFormData {
  teamName: string;
  captainName: string;
  email: string;
  phone: string;
  location: string;
  proofOfPayment: File | null;
}

const GOLD = '#C5A059';
const GOLD_LIGHT = '#F3E5AB';
const DARK = '#0B0F19';
const CARD = '#111827';

export const KingsTableRegistration = () => {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'payfast' | 'eft'>('payfast');
  const [formData, setFormData] = useState<KingsTableFormData>({
    teamName: '',
    captainName: '',
    email: '',
    phone: '',
    location: '',
    proofOfPayment: null,
  });

  const entryFee = 250.0;

  // If PayFast redirected the user back here, let them know where things stand.
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const status = params.get('status');
    if (status === 'success') {
      setStep(3);
    }
  }, []);

  const compressAndGetBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (event) => {
        const img = new Image();
        img.src = event.target?.result as string;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          const MAX_WIDTH = 1000;
          const MAX_HEIGHT = 1000;
          if (width > height) {
            if (width > MAX_WIDTH) { height *= MAX_WIDTH / width; width = MAX_WIDTH; }
          } else {
            if (height > MAX_HEIGHT) { width *= MAX_HEIGHT / height; height = MAX_HEIGHT; }
          }
          canvas.width = width; canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, width, height);
            resolve(canvas.toDataURL('image/jpeg', 0.6));
          } else {
            resolve(event.target?.result as string);
          }
        };
        img.onerror = (err) => reject(err);
      };
      reader.onerror = (err) => reject(err);
    });
  };

  const triggerPayfastRedirect = () => {
    const form = document.createElement('form');
    form.action = 'https://www.payfast.co.za/eng/process';
    form.method = 'POST';
    const fields = {
      merchant_id: '35471207',
      merchant_key: 'q9qkx9sqx9l3m',
      return_url: 'https://ludoleague.co.za/?page=kingstable&status=success',
      cancel_url: 'https://ludoleague.co.za/?page=kingstable&status=cancel',
      name_first: formData.captainName.split(' ')[0] || '',
      name_last: formData.captainName.split(' ').slice(1).join(' ') || '',
      email_address: formData.email,
      m_payment_id: `kt_${Date.now()}`,
      amount: entryFee.toFixed(2),
      item_name: "The King's Table Season 1 - Team Entry",
      custom_str1: 'kings_table_registration',
      custom_str2: formData.teamName,
    };
    Object.entries(fields).forEach(([key, value]) => {
      const input = document.createElement('input');
      input.type = 'hidden'; input.name = key; input.value = value;
      form.appendChild(input);
    });
    document.body.appendChild(form);
    form.submit();
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!db) {
      alert('Registration is temporarily unavailable. Please try again shortly.');
      return;
    }
    setIsSubmitting(true);
    try {
      let popUrl = '';
      if (paymentMethod === 'eft' && formData.proofOfPayment) {
        popUrl = await compressAndGetBase64(formData.proofOfPayment);
      }
      const registrationId = `kt_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
      await setDoc(doc(db, 'event_registrations', registrationId), {
        teamName: formData.teamName,
        fullName: formData.captainName,
        email: formData.email,
        phoneNumber: formData.phone,
        location: formData.location,
        paymentMethod,
        proofOfPaymentUrl: popUrl,
        amount: entryFee,
        status: paymentMethod === 'payfast' ? 'pending_online_payment' : 'pending_verification',
        eventName: "The King's Table - Season 1",
        type: 'kings_table',
        eventDate: '5 September 2026',
        timestamp: serverTimestamp(),
      });
      if (paymentMethod === 'payfast') {
        triggerPayfastRedirect();
      } else {
        setStep(3);
      }
    } catch (error) {
      console.error('King\'s Table registration failed:', error);
      alert('Registration failed. Please check your network and try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section
      id="kingstable-registration"
      className="min-h-screen w-full relative flex flex-col justify-center py-24 px-4 md:px-10"
      style={{ background: DARK, color: '#fff' }}
    >
      <div className="w-full max-w-2xl mx-auto">
        <div className="text-center mb-10">
          <div
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs uppercase tracking-[0.2em] mb-4"
            style={{ background: 'rgba(197,160,89,0.15)', border: `1px solid ${GOLD}`, color: GOLD_LIGHT }}
          >
            <Crown size={14} /> Season 1
          </div>
          <h1
            className="text-4xl md:text-5xl font-black uppercase tracking-wide mb-3"
            style={{
              background: `linear-gradient(180deg, ${GOLD_LIGHT} 0%, ${GOLD} 100%)`,
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}
          >
            The King's Table
          </h1>
          <p className="text-slate-400">Register your team. Entry is R250 per team.</p>
        </div>

        <div className="p-8 rounded-2xl shadow-2xl" style={{ background: CARD, border: '1px solid #1f2937' }}>
          {step === 1 && (
            <form onSubmit={(e) => { e.preventDefault(); setStep(2); }} className="space-y-6">
              <h3 className="text-2xl font-black uppercase" style={{ color: GOLD_LIGHT }}>Step 1: Team Details</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <input
                  id="kt-teamname" name="teamName" required type="text" placeholder="Team Name"
                  className="w-full sm:col-span-2 bg-neutral-900/60 border border-neutral-800 rounded-xl p-4 text-white font-bold outline-none focus:border-[#C5A059]"
                  value={formData.teamName} onChange={e => setFormData({ ...formData, teamName: e.target.value })}
                />
                <input
                  id="kt-captain" name="captainName" required type="text" placeholder="Captain Full Name" autoComplete="name"
                  className="w-full bg-neutral-900/60 border border-neutral-800 rounded-xl p-4 text-white font-bold outline-none focus:border-[#C5A059]"
                  value={formData.captainName} onChange={e => setFormData({ ...formData, captainName: e.target.value })}
                />
                <input
                  id="kt-email" name="email" required type="email" placeholder="Email" autoComplete="email"
                  className="w-full bg-neutral-900/60 border border-neutral-800 rounded-xl p-4 text-white font-bold outline-none focus:border-[#C5A059]"
                  value={formData.email} onChange={e => setFormData({ ...formData, email: e.target.value })}
                />
                <input
                  id="kt-phone" name="phone" required type="tel" placeholder="Phone Number" autoComplete="tel"
                  className="w-full bg-neutral-900/60 border border-neutral-800 rounded-xl p-4 text-white font-bold outline-none focus:border-[#C5A059]"
                  value={formData.phone} onChange={e => setFormData({ ...formData, phone: e.target.value })}
                />
                <input
                  id="kt-location" name="location" required type="text" placeholder="Location (Town / Township)" autoComplete="address-level2"
                  className="w-full bg-neutral-900/60 border border-neutral-800 rounded-xl p-4 text-white font-bold outline-none focus:border-[#C5A059]"
                  value={formData.location} onChange={e => setFormData({ ...formData, location: e.target.value })}
                />
              </div>
              <button
                type="submit"
                className="w-full py-4 font-black uppercase tracking-widest rounded-xl transition-all shadow-lg"
                style={{ background: `linear-gradient(135deg, ${GOLD}, #A07C3F)`, color: DARK }}
              >
                Next: Payment
              </button>
            </form>
          )}

          {step === 2 && (
            <form onSubmit={handleRegister} className="space-y-6">
              <h3 className="text-2xl font-black uppercase" style={{ color: GOLD_LIGHT }}>Step 2: Choose Payment</h3>
              <div className="grid grid-cols-2 gap-4">
                <button
                  type="button" onClick={() => setPaymentMethod('payfast')}
                  className="p-4 rounded-xl border-2 flex flex-col items-center gap-2 font-bold transition-all"
                  style={paymentMethod === 'payfast' ? { borderColor: GOLD, background: '#1a1f2b' } : { borderColor: '#1f2937' }}
                >
                  <CreditCard size={20} style={{ color: GOLD }} /> Payfast Online
                </button>
                <button
                  type="button" onClick={() => setPaymentMethod('eft')}
                  className="p-4 rounded-xl border-2 flex flex-col items-center gap-2 font-bold transition-all"
                  style={paymentMethod === 'eft' ? { borderColor: GOLD, background: '#1a1f2b' } : { borderColor: '#1f2937' }}
                >
                  <Landmark size={20} style={{ color: GOLD }} /> Manual EFT
                </button>
              </div>

              {paymentMethod === 'eft' ? (
                <div className="space-y-6">
                  <div className="p-5 rounded-xl border text-sm text-neutral-300 space-y-2" style={{ background: DARK, borderColor: '#1f2937' }}>
                    <p><b>Bank Name:</b> Nedbank</p>
                    <p><b>Account Holder:</b> THE LUDO LEAGUE SOUTH AFRICA (PTY) LTD</p>
                    <p><b>Account Number:</b> 1120230365</p>
                    <p><b>Branch Code:</b> 198765</p>
                    <p><b>Account Type:</b> Current Account</p>
                    <p><b>Required Entry Fee:</b> R{entryFee.toFixed(2)}</p>
                    <p><b>Reference:</b> KT-{formData.teamName.replace(/\s+/g, '')}</p>
                  </div>
                  <div className="border-2 border-dashed rounded-xl p-6 flex flex-col items-center justify-center cursor-pointer relative" style={{ borderColor: '#374151', background: 'rgba(255,255,255,0.02)' }}>
                    <UploadCloud size={32} className="text-neutral-500 mb-2" />
                    <span className="text-xs font-black" style={{ color: GOLD_LIGHT }}>
                      {formData.proofOfPayment ? formData.proofOfPayment.name : 'Upload Proof of Payment (EFT)'}
                    </span>
                    <input
                      id="kt-proof" name="proofOfPayment" required={paymentMethod === 'eft'} type="file" accept=".pdf,image/*"
                      className="absolute inset-0 opacity-0 cursor-pointer"
                      onChange={e => setFormData({ ...formData, proofOfPayment: e.target.files ? e.target.files[0] : null })}
                    />
                  </div>
                </div>
              ) : (
                <div className="p-6 rounded-2xl border text-center space-y-4 text-sm text-neutral-300" style={{ background: DARK, borderColor: '#1f2937' }}>
                  <p><b>Total Entry Fee:</b> <span style={{ color: GOLD }} className="font-black">R{entryFee.toFixed(2)}</span></p>
                  <div className="border-t pt-3 space-y-1.5 text-xs text-neutral-500" style={{ borderColor: '#1f2937' }}>
                    <p className="font-bold text-neutral-400 uppercase tracking-wider">Accepted Payment Methods:</p>
                    <p>Visa - Mastercard - Maestro - Instant EFT - Capitec Pay - SnapScan - Zapper</p>
                  </div>
                </div>
              )}

              <div className="flex gap-4">
                <button type="button" onClick={() => setStep(1)} className="w-1/2 py-4 bg-neutral-900 rounded-xl text-white font-bold hover:bg-neutral-800 transition-colors">
                  Back
                </button>
                <button
                  type="submit" disabled={isSubmitting || (paymentMethod === 'eft' && !formData.proofOfPayment)}
                  className="w-1/2 py-4 font-black uppercase tracking-widest rounded-xl disabled:opacity-50 flex items-center justify-center shadow-lg transition-all"
                  style={{ background: '#D32F2F', color: '#fff' }}
                >
                  {isSubmitting ? <Loader2 className="animate-spin" size={18} /> : paymentMethod === 'payfast' ? 'Pay Now' : 'Complete Registration'}
                </button>
              </div>
            </form>
          )}

          {step === 3 && (
            <div className="text-center space-y-6 py-6">
              <div className="w-20 h-20 rounded-full flex items-center justify-center mx-auto" style={{ background: 'rgba(16,185,129,0.1)', color: '#10b981' }}>
                <CheckCircle2 size={48} />
              </div>
              <h3 className="text-2xl font-black uppercase text-white">Team Registered</h3>
              <p className="text-neutral-400 leading-relaxed">
                Thank you for entering The King's Table Season 1! Your registration is logged and pending payment verification.
                We'll be in touch by email ahead of the 5th September start.
              </p>
              <button
                onClick={() => { setStep(1); setPaymentMethod('payfast'); setFormData({ teamName: '', captainName: '', email: '', phone: '', location: '', proofOfPayment: null }); }}
                className="w-full py-4 bg-neutral-900 hover:bg-neutral-800 text-white font-black uppercase tracking-widest rounded-xl transition-all"
              >
                Back to Start
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
